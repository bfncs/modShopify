<?php

return array(
  'limit' => '50',
  'page' => '1',
  'published_status' => 'published',
  
  'containerTpl' => 'modshopifyOuterTpl',
  'productTpl' => 'modshopifyProductTpl',
  'productImgTpl' => 'modshopifyProductImgTpl',
  'productVariantTpl' => 'modshopifyProductVariantTpl',
  
  'thumbsWidth' => 200,
  'thumbsHeight' => 200,
  'thumbsArgs' => '&zc=1'
  
);
