--------------------
Extra: modShopify
Developer: Marc Loehe (@boundaryfunc)
--------------------
Version: 1.0
 
A modX extra to show Shopify Products.
